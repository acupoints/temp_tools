# STEPS

## 01

```bash
# plugins\rhs_v2\rhs_cfg.txt 包含有插件调用的路径，Gamma工具路径不对则无法完成转换，进而不能生成目标文件
# GammaOutputPath 支持.png/.jpg

```
